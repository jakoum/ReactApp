import './App.css';
import React, {useState} from 'react';
import Component from './Component';

function App() {
  
   
    const [error,setError]=useState("")
    const [user,setUser]=useState({name:"",eamil:""})
    
    const Login=details=>{
      console.log(details)
      if(details){
        setUser({name:details.name,
          email:details.password})
          console.log("logged in")
     }else{
       console.log("details does not match")
       setError("details does not match")
     }
    }
    const logout=()=>{
      setUser({name:"",eamil:""})
    }
  return (
    
    <div className="Componentt">
      
      {(user.name!="")?(
        <div>
        <h1>welcome,<span>{user.name}</span></h1>
        <button onClick={logout}>logout</button>
        </div>
):(
  <Component Login={Login} Error={error} />
)
      }
      
    </div>
  );
}

export default App;